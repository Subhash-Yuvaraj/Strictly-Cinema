


//country dropdown

document.addEventListener('DOMContentLoaded', () => {
    const selectDrop = document.querySelector('#countries');
    fetch('../js/country.json').
        then(res => {
            return res.json();
        }).then(
            data => {
                result = "";
                data.forEach(country => {
                    result += `<option value=${country.name}>${country.name}</option>`;
                })
                selectDrop.innerHTML = result;
            }
    ).catch(err =>
    {
        console.log(err);
            })
})