var maxval_horizontal = 0,
    maxval_vertical = 0;

// Horizontal
$('#TicketsByStageChart .get').find('.percent').each(function(){
  maxval_horizontal += parseInt( $(this).val() );
});
o.init('horizontal', $('#TicketsByStageChart'), 'TicketsByStageDiagram', maxval_horizontal );

// Vertical
$('#TicketsCountChart').find('.percent').each(function(){
  maxval_vertical += parseInt( $(this).val() )
});
o.init('vertical', $('#TicketsCountChart'), 'TicketCountDiagram', maxval_vertical );

