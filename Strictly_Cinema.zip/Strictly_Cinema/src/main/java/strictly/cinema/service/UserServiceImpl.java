package strictly.cinema.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import strictly.cinema.entity.UserRepository;
import strictly.cinema.model.User;
@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepository repo;
	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		return repo.save(user);
	}
	@Override
	public boolean checkEmail(String email) {
		// TODO Auto-generated method stub
		return repo.existsByEmail(email);
	}
	@Override
	public boolean checkName(String name) {
		// TODO Auto-generated method stub
		return repo.existsByName(name);
	}
	@Override
	public void updateResetPassword(String token,String email) throws UserNotFoundException {
		User user=repo.findByEmail(email);
		if(user!=null) {
			user.setResetPasswordToken(token);
			repo.save(user);
		}
		else {
			throw new UserNotFoundException("Could not find user with the email "+ email);
		}
	}
	@Override
	public User get(String resetPasswordToken) {
		return repo.findByResetPasswordToken(resetPasswordToken);
	}
	@Override
	public User getUser(String string) {
		return repo.findByName(string);
	}
	public void updatePassword(User user,String newPassword) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword=passwordEncoder.encode(newPassword);
		user.setPassword(encodedPassword);
		user.setResetPasswordToken(null);
		repo.save(user);	
	}
	
}
