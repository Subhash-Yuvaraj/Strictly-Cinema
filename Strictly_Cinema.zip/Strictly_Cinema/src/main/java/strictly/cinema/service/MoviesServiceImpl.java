package strictly.cinema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import strictly.cinema.entity.MoviesRepository;
import strictly.cinema.model.Movies;
@Service
public class MoviesServiceImpl implements MoviesService{
	@Autowired
	MoviesRepository repo;
	@Override
	public Movies addMovie(Movies movie) {
		// TODO Auto-generated method stub
		return repo.save(movie);
	}
	@Override
	public List<Movies> getAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	@Override
	public Movies getMovie(Integer m_id) {
		// TODO Auto-generated method stub
		return repo.getById(m_id);
	}

}
