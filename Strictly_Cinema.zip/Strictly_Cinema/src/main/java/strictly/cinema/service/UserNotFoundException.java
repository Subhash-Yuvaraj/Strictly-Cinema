package strictly.cinema.service;

public class UserNotFoundException extends Exception {
	public UserNotFoundException(String s) {
		super(s);
	}
}
