package strictly.cinema.service;

import strictly.cinema.model.User;

public interface UserService {
	public User createUser(User user);
	public boolean checkEmail(String email);
	public boolean checkName(String name);
	public void updateResetPassword(String token,String email) throws UserNotFoundException;
	public User get(String resetPasswordToken);
	public User getUser(String string);
}
