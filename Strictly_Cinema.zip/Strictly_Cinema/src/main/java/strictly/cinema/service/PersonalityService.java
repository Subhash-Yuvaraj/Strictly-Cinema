package strictly.cinema.service;



import java.util.List;

import strictly.cinema.model.Personality;

public interface PersonalityService {
	public Personality addPersonality(Personality person);
	public List<Personality> getAll();
	public Personality getPersonality(int p_id);
	public Personality findByName(String name);
}
