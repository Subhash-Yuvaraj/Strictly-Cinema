package strictly.cinema.service;

import java.util.List;

import strictly.cinema.model.Movies;
import strictly.cinema.model.Review;

public interface ReviewService {
	public Review addReview(Review review);
}
