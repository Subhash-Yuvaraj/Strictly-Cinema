package strictly.cinema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import strictly.cinema.entity.PersonalityRepository;
import strictly.cinema.model.Personality;

@Service
public class PersonalityServiceImpl implements PersonalityService{
	@Autowired
	PersonalityRepository repo;

	@Override
	public Personality addPersonality(Personality person) {
		// TODO Auto-generated method stub
		return repo.save(person);
	}

	@Override
	public List<Personality> getAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Personality getPersonality(int p_id) {
		// TODO Auto-generated method stub
		return repo.getById(p_id);
	}

	@Override
	public Personality findByName(String name) {
		// TODO Auto-generated method stub
		return repo.findByName(name);
	}
	
	
}
