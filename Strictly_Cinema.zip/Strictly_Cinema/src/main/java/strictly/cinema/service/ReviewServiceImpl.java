package strictly.cinema.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import strictly.cinema.entity.ReviewRepository;
import strictly.cinema.model.Movies;
import strictly.cinema.model.Review;

@Service
public class ReviewServiceImpl implements ReviewService{
	@Autowired
	private ReviewRepository repository;
	@Override
	public Review addReview(Review review) {
		// TODO Auto-generated method stub
		return repository.save(review);
	}
//	
	public List<Integer> rating(int m_id){
		List<Integer> r=new ArrayList<Integer>();
		for(int i=1;i<6;i++) {
			r.add(repository.findCountByNo_of_stars(i,m_id));
		}
		return r;
	}
	

}
