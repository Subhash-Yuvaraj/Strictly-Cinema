package strictly.cinema.service;

import java.util.List;

import strictly.cinema.model.Movies;

public interface MoviesService {
	public Movies addMovie(Movies movie);
	public List<Movies> getAll();
	public Movies getMovie(Integer m_id);
}
