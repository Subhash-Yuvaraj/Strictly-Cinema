package strictly.cinema.model;

import java.sql.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.JoinColumn;

@Entity
@Table(name="Personality")
public class Personality {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int p_id;
	@Column(nullable = false, length = 50)
	private String name;
	@Column(nullable = true)
	private java.sql.Date dob;
	@Column(nullable = false, length = 30)
	private String nationality;
	@Column(nullable = false, length = 20)
	private String known_for;
	@Column(nullable=true,length=100)
	private String image;
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Personality() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getKnown_for() {
		return known_for;
	}
	public void setKnown_for(String known_for) {
		this.known_for = known_for;
	}

	public Personality(int p_id, String name, Date dob, String nationality, String known_for, String image,
			Set<Movies> directedMovies, Set<Movies> actedMovies) {
		super();
		this.p_id = p_id;
		this.name = name;
		this.dob = dob;
		this.nationality = nationality;
		this.known_for = known_for;
		this.image = image;
		actedMovies = directedMovies;
		directedMovies = actedMovies;
	}
	public Set<Movies> getActedMovies() {
		return directedMovies;
	}
	public void setActedMovies(Set<Movies> actedMovies) {
		directedMovies = actedMovies;
	}
	public Set<Movies> getDirectedMovies() {
		return actedMovies;
	}
	public void setDirectedMovies(Set<Movies> directedMovies) {
		actedMovies = directedMovies;
	}
	@ManyToMany(mappedBy="directors",fetch=FetchType.LAZY)	
	@JsonBackReference
	private Set<Movies> directedMovies;
	@ManyToMany(mappedBy="actors",fetch=FetchType.LAZY)
	@JsonManagedReference
	@JsonBackReference
	private Set<Movies> actedMovies;
	@Transient
	public String getpersonalityPath() {
		if(image==null)
			return null;
		return "/personality-images/" + p_id+ "/" + image;
	}
}
