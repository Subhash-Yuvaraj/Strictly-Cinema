package strictly.cinema.model;

import java.sql.Date;
import java.util.Set;

import javax.persistence.*;

import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


@Entity
@Table(name="User")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int u_id;
	@Column(nullable = false, unique = true, length = 30)
	private String email;
	@Column(nullable = false, length = 30)
	private String name;
	@Column(nullable = true, length = 30)
	private Date dob;
	@Column(nullable = false, length = 32)
	private String password;
	@Column(nullable = false, length = 10)
	private String role;
	@Column(name="reset_password_token")
	private String resetPasswordToken;
//	@OneToMany(mappedBy="user",cascade=CascadeType.ALL)
//	private Set<Review> reviews;
//	public Set<Review> getReviews() {
//		return reviews;
//	}
//	public void setReviews(Set<Review> reviews) {
//		this.reviews = reviews;
//	}
//	public User(int u_id, String email, String name, Date dob, String password, String role, String resetPasswordToken,
//			Set<Review> reviews) {
//		super();
//		this.u_id = u_id;
//		this.email = email;
//		this.name = name;
//		this.dob = dob;
//		this.password = password;
//		this.role = role;
//		this.resetPasswordToken = resetPasswordToken;
//		this.reviews = reviews;
//	}
	public User() {
		// TODO Auto-generated constructor stub
	}
	public String getResetPasswordToken() {
		return resetPasswordToken;
	}
	public void setResetPasswordToken(String resetPasswordToken) {
		this.resetPasswordToken = resetPasswordToken;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getPassword() {
		return password;
	}
	public int getU_id() {
		return u_id;
	}
	public void setU_id(int u_id) {
		this.u_id = u_id;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}
	public boolean hasRole(String roleName) {
       return this.role.equals(roleName);
    }
}
