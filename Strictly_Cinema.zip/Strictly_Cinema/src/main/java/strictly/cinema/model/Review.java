package strictly.cinema.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Review")
public class Review {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int r_id;
	@Column(nullable=false)
	private int no_of_stars;
	@Column(name="review_desc",nullable=true,length=250)
	private String desc;
	@ManyToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="u_id")
	private User user;
	@ManyToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="m_id")
	private Movies movie;
	public int getR_id() {
		return r_id;
	}
	public void setR_id(int r_id) {
		this.r_id = r_id;
	}
	public int getNo_of_stars() {
		return no_of_stars;
	}
	public void setNo_of_stars(int no_of_stars) {
		this.no_of_stars = no_of_stars;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Movies getMovie() {
		return movie;
	}
	public void setMovie(Movies movie) {
		this.movie = movie;
	}
	public Review() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Review(int r_id, int no_of_stars, String desc, User user, Movies movie) {
		super();
		this.r_id = r_id;
		this.no_of_stars = no_of_stars;
		this.desc = desc;
		this.user = user;
		this.movie = movie;
	}
	
}
