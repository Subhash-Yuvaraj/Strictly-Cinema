package strictly.cinema.model;

import java.sql.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="Movies")
public class Movies {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int m_id;
	@Column(nullable = false, length = 50)
	private String title;
	@Column(nullable=false)
	private java.sql.Date release_date;
	@Column(nullable=false,length=30)
	private String language;
	@Column(nullable=false,length=20)
	private String certificate;
	@Column(nullable=false)
	private int run_time;
	@Column(nullable=true,length=100)
	private String poster;
	@Column(nullable=false,length=100)
	private String trailer;
	public int getM_id() {
		return m_id;
	}
	public void setM_id(int m_id) {
		this.m_id = m_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public java.sql.Date getRelease_date() {
		return release_date;
	}
	public void setRelease_date(java.sql.Date release_date) {
		this.release_date = release_date;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCertificate() {
		return certificate;
	}
	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}
	public int getRun_time() {
		return run_time;
	}
	public void setRun_time(int run_time) {
		this.run_time = run_time;
	}
	public String getPoster() {
		return poster;
	}
	public void setPoster(String poster) {
		this.poster = poster;
	}
	public String getTrailer() {
		return trailer;
	}
	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}
	public Movies() {
		super();
		// TODO Auto-generated constructor stub
	}
	@ManyToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinTable(name="Director",joinColumns= {@JoinColumn(name="m_id",referencedColumnName="m_id")},inverseJoinColumns= {@JoinColumn(name="p_id",referencedColumnName="p_id")})
	@JsonManagedReference
	private Set<Personality> directors;
	@ManyToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinTable(name="Casting",joinColumns= {@JoinColumn(name="m_id",referencedColumnName="m_id")},inverseJoinColumns= {@JoinColumn(name="p_id",referencedColumnName="p_id")})
	@JsonManagedReference
	private Set<Personality> actors;
	
	public Set<Personality> getDirectors() {
		return directors;
	}
	public void setDirectors(Set<Personality> directors) {
		this.directors = directors;
	}
	public Set<Personality> getActors() {
		return actors;
	}
	public void setActors(Set<Personality> actors) {
		this.actors = actors;
	}
	@OneToMany(mappedBy="movie",cascade=CascadeType.ALL)
	private Set<Review> reviews;
	public Movies(int m_id, String title, Date release_date, String language, String certificate, int run_time,
			String poster, String trailer, Set<Personality> directors, Set<Personality> actors, Set<Review> reviews) {
		super();
		this.m_id = m_id;
		this.title = title;
		this.release_date = release_date;
		this.language = language;
		this.certificate = certificate;
		this.run_time = run_time;
		this.poster = poster;
		this.trailer = trailer;
		this.directors = directors;
		this.actors = actors;
		this.reviews = reviews;
	}
	@Transient
	public String getmoviesPath() {
		if(poster==null)
			return null;
		return "/movies-images/"+m_id+"/"+poster;
	}
}
