package strictly.cinema.config;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
@Configuration
public class MvcConfig implements WebMvcConfigurer{
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		Path personalityUploadDir=Paths.get("./personality-images/");
		String personalityUploadPath=personalityUploadDir.toFile().getAbsolutePath();
		registry.addResourceHandler("/personality-images/**").addResourceLocations("file:/"+personalityUploadPath+"/");
		Path moviesUploadDir=Paths.get("./movies-images/");
		String moviesUploadPath=moviesUploadDir.toFile().getAbsolutePath();
		registry.addResourceHandler("/movies-images/**").addResourceLocations("file:/"+moviesUploadPath+"/");
		registry.addResourceHandler("/resources/**")
        .addResourceLocations("file:/home/subhash/Documents/workspace-spring-tool-suite-4-4.12.1.RELEASE/Striclty_Cinema/");
	}
	
}
