package strictly.cinema.config;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.stereotype.Component;

@Component
public class LogoutHandler extends SimpleUrlLogoutSuccessHandler {


@Override
public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
        throws IOException, ServletException {
    if(!response.isCommitted()) {
        String targetURL = "home";
        response.setContentType(MediaType.TEXT_PLAIN_VALUE);
        response.getWriter().write(targetURL);
        response.getWriter().flush();
        response.getWriter().close();
        getRedirectStrategy().sendRedirect(request, response, targetURL);
        response.setStatus(HttpServletResponse.SC_TEMPORARY_REDIRECT);
        response.setHeader("Location", targetURL);

    }

 }

}
