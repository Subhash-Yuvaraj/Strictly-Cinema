package strictly.cinema.controller;


import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.Principal;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.data.repository.query.Param;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.hash.Hashing;

import net.bytebuddy.utility.RandomString;
import strictly.cinema.config.CustomAuthenticationSuccessHandler;
import strictly.cinema.config.Utility;
import strictly.cinema.model.Personality;
import strictly.cinema.model.User;
import strictly.cinema.service.MoviesServiceImpl;
import strictly.cinema.service.PersonalityServiceImpl;
import strictly.cinema.service.UserNotFoundException;
import strictly.cinema.service.UserServiceImpl;
//import strictly.cinema.service.Validation;

@Controller

public class HomeController {
	@Autowired
	private UserServiceImpl userService;
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	@Autowired
	private MoviesServiceImpl moviesService;
	@Autowired
	private PersonalityServiceImpl personalityService;
//	@Autowired
//	private Validation validate;
//	?
	
	@Autowired
	private JavaMailSender mailSender;
	@GetMapping("/")
	public String home() {
		return "home";
	}
	@GetMapping("/home")
	public String homeBeforeLogin() {
		return "home";
	}
	@GetMapping("/login")
	public String login(Model model, Principal principal, HttpServletRequest request) throws Exception{
        String referer = request.getHeader("Referer"); //Get previous URL before call '/login'

        //save referer URL to session, for later use on CustomAuthenticationSuccesshandler
        request.getSession().setAttribute(CustomAuthenticationSuccessHandler.REDIRECT_URL_SESSION_ATTRIBUTE_NAME, referer); 


        return principal == null ?  "login" : "redirect:/"; 
    }
	@GetMapping("/viewMovies")
	public String viewMovies(ModelMap m) {
		m.put("movies", moviesService.getAll());
		return "viewMovies";
	}
	@GetMapping("/viewPersonalities")
	public String viewPersonality(HttpSession session,ModelMap m) {
		m.put("personalities", personalityService.getAll());
		return "viewPersonalities";
	}
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	@GetMapping("/charts")
	public String chart() {
		return "charts";
	}
	@PostMapping(path="/register")
	public String createUser(HttpSession session,@RequestParam String name,@RequestParam String dob,@RequestParam String email,@RequestParam String password,@RequestParam String role) {
		User user=new User();
		user.setName(name);
		user.setDob(java.sql.Date.valueOf( dob ));
		user.setEmail(email);
		user.setPassword(password);
		user.setRole(role);
		if(userService.checkEmail(user.getEmail())) {
			session.setAttribute("message", "Email id already exists");
		}
		else if(userService.checkName(name)) {
			session.setAttribute("message", "User name already taken");
		}
		
		else {
			user.setPassword(passwordEncoder.encode(user.getPassword()));
			User u=userService.createUser(user);
			if(u!=null) {
				session.setAttribute("message", "Resitered Successfully");
			}
			else {
				session.setAttribute("message", "Server Error");
			}
		}
		
		return "redirect:/register";
	}
	
	
	@GetMapping("/forgotpassword")
	public String showForm(Model m) {
		m.addAttribute("pageTitle","Forgot Password");
		return "forgotpassword";
	}
	@PostMapping("/forgotpassword")
	public String sendRequest(HttpServletRequest http,ModelMap m)  {
		String email=http.getParameter("email");
		String token=RandomString.make(45);
		try {
			userService.updateResetPassword(token, email);
			String resetPasswordLink=Utility.getSiteURL(http)+"/resetpassword?token="+token;
			sendEmail(email,resetPasswordLink);
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			m.put("error",e.getMessage());
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			m.put("error",e.getMessage());
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			m.put("error",e.getMessage());
		}
		return "forgotpassword";
	}
//	@Bean
//	public BCryptPasswordEncoder passwordEncoder() {
//	    return new BCryptPasswordEncoder();
//	}
	private void sendEmail(String email, String resetPasswordLink) throws UnsupportedEncodingException, MessagingException {
		// TODO Auto-generated method stub
		MimeMessage msg=mailSender.createMimeMessage();
		MimeMessageHelper helper=new MimeMessageHelper(msg);
		helper.setFrom("contact@strictlycinema.com", "Strictly Cinema Support");
		helper.setTo(email);
		String subject="Here's the link to reset your mail";
		String content="<p>Hello</p>"
			+"You have requested to reset your password."
			+"Click the below link to change your password:"
			+"<a href=\""+resetPasswordLink+ "\">Click here</a>"
			+"<p>Ignore this email if you remember your password</p>";
		helper.setSubject(subject);
		helper.setText(content,true);
		mailSender.send(msg);	
	}
	@GetMapping("/resetpassword")
	public String resetPasswordForm(@Param(value="token")String token,Model m) {
		User user=userService.get(token);
		if(user==null) {
			m.addAttribute("title","Reset your password");
			m.addAttribute("message","Invalid token");
			return "message";
			
		}
		m.addAttribute("token",token);
		m.addAttribute("pageTitle","Reset Your Password");
		return "resetpassword";
	}
	@PostMapping("/resetpassword")
	public String processResetPassword(HttpServletRequest request,Model m) {
		String token=request.getParameter("token");
		String password=request.getParameter("password");
		User user=userService.get(token);
		if(user==null) {
			m.addAttribute("title","Reset your password");
			m.addAttribute("error","Invalid token");
			return "resetpassword";
			
		}
		else {
			userService.updatePassword(user, password);
			m.addAttribute("error", "You have successfully changed the password");
		}
		return "resetpassword";
	}
}
