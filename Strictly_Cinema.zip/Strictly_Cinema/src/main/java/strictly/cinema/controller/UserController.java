package strictly.cinema.controller;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import strictly.cinema.model.Review;
import strictly.cinema.model.User;
import strictly.cinema.service.MoviesServiceImpl;
import strictly.cinema.service.PersonalityServiceImpl;
import strictly.cinema.service.ReviewServiceImpl;
import strictly.cinema.service.UserServiceImpl;

@Controller
public class UserController {
	@Autowired
	private UserServiceImpl userService;
	@Autowired
	private MoviesServiceImpl moviesService;
	@Autowired
	private ReviewServiceImpl reviewService;
	@Autowired
	private PersonalityServiceImpl personalityService;
	@GetMapping("/userhome")
	public String userhome(HttpSession session) {
		return "userhome";
	}
	@GetMapping("/viewMovie")
	public String viewMovie(HttpServletRequest request,RedirectAttributes ra,ModelMap m,@RequestParam int m_id) {
		User user=userService.getUser(request.getUserPrincipal().getName());
		int age=calculateAge(user.getDob().toLocalDate(),LocalDate.now());
		System.out.println(age);
		if(age<19 && moviesService.getMovie(m_id).getCertificate().equalsIgnoreCase("r-rated")) {
			m.put("msg", "You are not eligible to access the content");
			System.out.println("hello");
			return "message";
		}
		
		m.put("movie", moviesService.getMovie(m_id));
		List<Integer>rating=reviewService.rating(m_id);
		Iterator<Integer> it=rating.iterator();
		double x=0;
		int t=0;
		int i=1;
		while(it.hasNext()) {
			int y=(int) it.next();
			t+=y;
			x+=i*y;
			i++;
		}
		x/=(t);
		m.put("avg", x);
		m.put("rating", rating);		
		return "viewMovie";
	}
	public int calculateAge(LocalDate birthDate, LocalDate currentDate) {
        if ((birthDate != null) && (currentDate != null)) {
            return Period.between(birthDate, currentDate).getYears();
        } else {
            return 0;
        }
    }
	@GetMapping("/thirdparty")
	public String thirdParty() {
		return "thirdparty";
	}
	@GetMapping("/viewPersonality")
	public String viewPersonality(ModelMap m,@RequestParam int p_id) {
		m.put("personality", personalityService.getPersonality(p_id));
		return "viewPersonality";
	}
	@PostMapping("/viewMovie")
	public String addReview(RedirectAttributes ra,HttpServletRequest request,@RequestParam int m_id,@RequestParam int no_of_stars,@RequestParam String review_desc) {
		User user=userService.getUser(request.getUserPrincipal().getName());
		Review review=new Review();
		System.out.println(user.getRole()+"\n"+no_of_stars+"\n"+review_desc);
		review.setNo_of_stars(no_of_stars);
		review.setMovie(moviesService.getMovie(m_id));
		review.setUser(user);
		review.setDesc(review_desc);
		reviewService.addReview(review);
		return "redirect:/viewMovies";
	}
}
