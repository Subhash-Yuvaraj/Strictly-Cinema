package strictly.cinema.controller;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import strictly.cinema.model.Movies;
import strictly.cinema.model.Personality;
import strictly.cinema.service.MoviesServiceImpl;
import strictly.cinema.service.PersonalityServiceImpl;

//import strictly.cinema.model.Personality;
//import strictly.cinema.service.PersonalityServiceImpl;

@Controller
public class AdminController {
	@Autowired
	PersonalityServiceImpl personalityServiceImpl;
	@Autowired
	MoviesServiceImpl moviesServiceImpl;
	@Autowired
	private PersonalityServiceImpl personalityService;
	@GetMapping("/addPersonality")
	public String viewAddPersonality() {
		return "addPersonality";
	}
	
	@PostMapping("/addPersonality")
	public String addPersonality(HttpSession session,@RequestParam String name,@RequestParam String dob,@RequestParam String nationality,@RequestParam String known_for,RedirectAttributes ra,@RequestParam("fileImage") MultipartFile multipartFile) throws IOException{
		Personality p=new Personality();
		p.setName(name);
		p.setDob(java.sql.Date.valueOf( dob ));
		p.setKnown_for(known_for);
		p.setNationality(nationality);
		String image=StringUtils.cleanPath(multipartFile.getOriginalFilename());
		p.setImage(image);
		Personality personality = personalityServiceImpl.addPersonality(p);
		String uploadDir="./personality-images/"+personality.getP_id();
		Path uploadPath=Paths.get(uploadDir);
		if(!Files.exists(uploadPath))
			Files.createDirectories(uploadPath);
		try(InputStream is=multipartFile.getInputStream()){
			Path filePath=uploadPath.resolve(image);
			Files.copy(is,filePath, StandardCopyOption.REPLACE_EXISTING);
		}
		catch(IOException e) {
			 throw new IOException("Couldn't save uploaded file");
		}
		ra.addFlashAttribute("message","Personality Successfully added");
		return "redirect:/addPersonality";
	}
	@GetMapping("/addMovie")
	public String viewAddMovie(HttpSession session,ModelMap m) {
		m.put("personalities", personalityService.getAll());
		return "addMovie";
	}
	@PostMapping("/addMovie")
	public String addMovie(HttpSession session,@RequestParam int run_time,@RequestParam String title,@RequestParam String release_date,@RequestParam String language,@RequestParam String certificate,@RequestParam String trailer,@RequestParam(value="director") List<String> director,@RequestParam(value="actor") List<String> actor,RedirectAttributes ra,@RequestParam("fileImage") MultipartFile multipartFile) throws IOException{
		System.out.println("hello");
		String image=StringUtils.cleanPath(multipartFile.getOriginalFilename());
		Movies m=new Movies();
		Set<Personality> actors=new HashSet<Personality>();
		Iterator it=actor.iterator();
		while(it.hasNext()) {
			
			String t=(String)it.next();
			System.out.println(t);
			actors.add(personalityService.findByName(t));
		}
		Set<Personality> directors=new HashSet<Personality>();
		Iterator iter=director.iterator();
		while(iter.hasNext()) {
			String t=(String)iter.next();
			System.out.println(t);
			directors.add(personalityService.findByName(t));
		}
		
		m.setActors(actors);
		m.setCertificate(certificate);
		m.setRelease_date(java.sql.Date.valueOf( release_date ));
		m.setDirectors(directors);
		m.setLanguage(language);
		m.setRun_time(run_time);
		m.setTitle(title);
		m.setPoster(image);
		m.setTrailer(trailer);
		Movies movie=moviesServiceImpl.addMovie(m);
		String uploadDir="./movies-images/"+movie.getM_id();
		Path uploadPath=Paths.get(uploadDir);
		if(!Files.exists(uploadPath))
			Files.createDirectories(uploadPath);
		try(InputStream is=multipartFile.getInputStream()){
			Path filePath=uploadPath.resolve(image);
			Files.copy(is,filePath, StandardCopyOption.REPLACE_EXISTING);
		}
		catch(IOException e) {
			 throw new IOException("Couldn't save uploaded file");
		}
		ra.addFlashAttribute("message","Movie Successfully added");

		return "redirect:/addMovie";
	}
	@GetMapping("/loginSuccess")
	public void getLoginInfo(@AuthenticationPrincipal UserDetails authentication,HttpServletResponse response) throws IOException {
	    if (authentication.getAuthorities()
	            .contains(new SimpleGrantedAuthority("ADMIN"))) {
	        response.sendRedirect("/adminhome");
	    } else {
	        response.sendRedirect("/userhome");
	    }
	}

	@GetMapping("/adminhome")
	public String adminDashboard(HttpSession session) {
		return "adminhome";
	}
	
}
