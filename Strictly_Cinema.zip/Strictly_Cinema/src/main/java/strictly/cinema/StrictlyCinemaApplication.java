package strictly.cinema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrictlyCinemaApplication {

	public static void main(String[] args) {
		SpringApplication.run(StrictlyCinemaApplication.class, args);
	}

}
