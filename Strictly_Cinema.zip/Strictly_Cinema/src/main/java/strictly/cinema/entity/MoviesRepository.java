package strictly.cinema.entity;

import org.springframework.data.jpa.repository.JpaRepository;

import strictly.cinema.model.Movies;

public interface MoviesRepository extends JpaRepository<Movies, Integer> {
	
}
