package strictly.cinema.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import strictly.cinema.model.Personality;
@Service
public interface PersonalityRepository extends JpaRepository<Personality,Integer>{
	public Personality findByName(String name);
}
