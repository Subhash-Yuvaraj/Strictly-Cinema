package strictly.cinema.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import strictly.cinema.model.Review;

public interface ReviewRepository extends JpaRepository<Review, Integer> {
	@Query(value="SELECT count(m_id) from Review r where r.no_of_stars=?1 and r.m_id=?2",nativeQuery = true)
	public Integer findCountByNo_of_stars(Integer no_of_stars,Integer m_id);
}
