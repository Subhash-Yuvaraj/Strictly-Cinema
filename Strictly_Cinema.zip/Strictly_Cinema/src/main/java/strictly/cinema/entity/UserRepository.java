package strictly.cinema.entity;

import org.springframework.data.jpa.repository.JpaRepository;

import strictly.cinema.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {
	public boolean existsByEmail(String email);
	public boolean existsByName(String name);
	public User findByName(String name);
	public User findByEmail(String email);
	public User findByResetPasswordToken(String token);
}
